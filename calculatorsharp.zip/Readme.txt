Copyrighted � 2013 by Greg McLeod
https://github.com/cleod9

Free to use and/or modify without notifying me. Just do not re-distribute it under anyone else's name please!

-----------------------------------

About Calculator#:

This is a program I wrote during one of my internships while I was learning C# and Visual Studio. It's essentially the basic Windows calculator re-coded from scratch, with a few scientific functions. There are also unit testing available for NUnit, which is great if you want to try manipulating the code and seeing if you break anything ;) (NUnit is downloaded separately of course, find it on Google)

This Calculator program should hopefully be a good reference to use if you want to see how "engine" code is separated from the GUI in a program.